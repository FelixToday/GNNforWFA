import os
import sys
from typing import Any, Dict, List, Optional, Union
from datetime import datetime
import json
import time
import csv

class BaseLogger:
    def __init__(self, json_save_path: str, log_save_path: str, log_to_console: bool = True):
        """
        初始化训练日志记录器

        参数:
            save_path: 日志文件保存路径(.json)
            log_to_console: 是否在控制台输出日志信息
        """
        self.json_save_path = json_save_path
        self.log_save_path = log_save_path
        self.time_buf = {}
        self.outputs: Dict[str, List[Any]] = {}
        self.outputs["metadata"] = {
            'create_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'update_at': None,
            'end_at': None
        }
        self.log_to_console = log_to_console

        # 配置日志格式
        self._configure_logging()

    def time_start(self, tag: str) -> None:
        """
        开始计时

        参数:
            tag: 计时标识符
        """
        self.time_buf[tag] = time.time()

    def time_end(self, tag: str) -> float:
        """
        结束计时并返回耗时(秒)

        参数:
            tag: 计时标识符

        返回:
            耗时(秒)
        """
        if tag not in self.time_buf:
            print(f"未找到计时标签: {tag}")

        duration = time.time() - self.time_buf[tag]
        del self.time_buf[tag]

        # 自动记录耗时到日志
        self._add_field(f"timing.{tag}", duration)
        self.info(f"{tag}:{duration:.2f} s")
        return duration

    def _configure_logging(self):
        """配置日志格式"""
        self.log_format = '%(asctime)s %(filename)s %(funcName)s [line:%(lineno)d] %(levelname)s %(message)s'
        self.date_format = '%Y-%m-%d %H:%M:%S,%f'

    def info(self, message: str, *args, is_logfile: bool = False, log_to_console: bool = True, **kwargs):
        """
        记录信息级别日志

        参数:
            message: 要记录的信息(可以使用%s等格式化占位符)
            *args: 格式化参数
            log_to_file: 是否写入日志
            **kwargs:
                - extra: 额外信息字典
        """
        # 获取调用信息
        frame = sys._getframe(1)
        filename = os.path.basename(frame.f_code.co_filename)
        func_name = frame.f_code.co_name
        lineno = frame.f_lineno

        # 格式化消息
        formatted_msg = message % args if args else message

        # 添加额外信息
        extra = kwargs.get('extra', {})
        if extra:
            formatted_msg += " " + " ".join(f"{k}={v}" for k, v in extra.items())

        # 格式化日志行
        log_entry = self.log_format % {
            'asctime': datetime.now().strftime(self.date_format)[:-3],  # 去掉最后3位微秒
            'filename': filename,
            'funcName': func_name,
            'lineno': lineno,
            'levelname': 'INFO',
            'message': formatted_msg
        }

        # 控制台输出
        if self.log_to_console and log_to_console:
            print(log_entry)

        # 文件输出
        if is_logfile:
            try:
                # 确保目录存在
                os.makedirs(os.path.dirname(os.path.abspath(self.log_save_path)), exist_ok=True)
                mode = 'a' if os.path.exists(self.log_save_path) else 'w'
                with open(self.log_save_path, mode, encoding='utf-8') as f:
                    f.write(log_entry + '\n')
            except Exception as e:
                print(f"写入日志文件失败: {e}", file=sys.stderr)

    def _add_field(self, field_name: str, value: Optional[Any] = None, replace: bool = False) -> None:
        """
        添加或更新日志字段

        参数:
            field_name: 字段名称(支持点号分隔的嵌套字段，如'metrics.accuracy')
            value: 要记录的值(可选)
        """
        keys = field_name.split('.')

        local_outputs=self.outputs
        for key in keys[:-1]:
            if key not in local_outputs:
                local_outputs[key] = {}
            local_outputs=local_outputs[key]
        final_key = keys[-1]
        if final_key not in local_outputs or replace:
            local_outputs[final_key] = value
        else:
            if isinstance(local_outputs[final_key], list):
                local_outputs[final_key].append(value)
            else:
                local_outputs[final_key] = [local_outputs[final_key], value]

    def clear_field(self, field_name: str) -> None:
        """
        清除指定字段(支持点号分隔的嵌套字段，如'metrics.accuracy')

        参数:
            field_name: 要清除的字段名称
        """

        keys = field_name.split('.')
        assert keys[0] != 'metadata', '不能删除 metadata'
        current = self.outputs

        try:
            # 遍历到倒数第二个key
            for key in keys[:-1]:
                current = current[key]

            # 删除最后一个key
            final_key = keys[-1]
            if final_key in current:
                del current[final_key]
        except (KeyError, TypeError):
            # 如果路径不存在，则忽略
            pass

    def log(self, field_name: str, value: Any, replace: bool = False) -> None:
        """
        记录值到指定字段

        参数:
            field_name: 字段名称
            value: 要记录的值
        """
        self._add_field(field_name, value, replace)
        self.outputs['metadata']['update_at'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.save_to_json()

    def save_to_json(self) -> None:
        """
        保存日志到JSON文件(包含元数据)
        不使用缩进，生成紧凑的JSON格式
        """
        os.makedirs(os.path.dirname(os.path.abspath(self.json_save_path)), exist_ok=True)
        self.outputs['metadata']["end_at"] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        duration_seconds = (
                datetime.strptime(self.outputs['metadata']["end_at"], '%Y-%m-%d %H:%M:%S') -
                datetime.strptime(self.outputs['metadata']["create_at"], '%Y-%m-%d %H:%M:%S')
        ).total_seconds()

        # 转换为 时:分:秒 格式
        hours = int(duration_seconds // 3600)
        minutes = int((duration_seconds % 3600) // 60)
        seconds = int(duration_seconds % 60)
        self.outputs['metadata']["duration"] = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        with open(self.json_save_path, 'w', encoding='utf-8') as f:
            json.dump(self.outputs, f, indent=4, ensure_ascii=False, separators=(',', ':'))

    def load_from_json(self) -> None:
        """
        从JSON文件加载日志数据
        """
        if os.path.exists(self.json_save_path):
            with open(self.json_save_path, 'r', encoding='utf-8') as f:
                self.outputs = json.load(f)


    def print_logs(self) -> None:
        """
        以美观格式打印当前日志内容
        """
        print(json.dumps(self.outputs, indent=4, ensure_ascii=False))
    def select_fields2csv(self, fields_list, savepath):

        def extract_list_of_dict(dict_list, prefix):
            """ 将 list[dict] 展开成多列，列名形如 prefix.key """
            result = {}
            if not dict_list:
                return result
            all_keys = set()
            for item in dict_list:
                if isinstance(item, dict):
                    all_keys.update(item.keys())
            for k in all_keys:
                col_name = f"{prefix}.{k}"
                col = []
                for item in dict_list:
                    if isinstance(item, dict):
                        col.append(item.get(k, ""))
                    else:
                        col.append("")
                result[col_name] = col
            return result

        def get_field_columns(field):
            """ 返回 dict: {col_name: col_values, ...} """
            # 支持 a.b 形式（显示请求子字段）
            if "." in field:
                parent, child = field.split(".", 1)
                parent_val = self.outputs.get(parent, "")

                # parent 是 list -> 从每个元素取 child
                if isinstance(parent_val, list):
                    col = []
                    for item in parent_val:
                        if isinstance(item, dict):
                            # 如果 child 里还包含点，则递归取值
                            if "." in child:
                                # 把 item 当作 outputs 临时对象处理 a.b.c 的剩余部分
                                # 简单实现：只支持一层点链（也可扩展）
                                sub_parent, sub_child = child.split(".", 1)
                                sub_val = item.get(sub_parent, "")
                                if isinstance(sub_val, dict):
                                    col.append(sub_val.get(sub_child, ""))
                                elif isinstance(sub_val, list):
                                    # 如果是 list，这里返回字符串以避免复杂展平冲突
                                    col.append(str(sub_val))
                                else:
                                    col.append(sub_val if sub_val is not None else "")
                            else:
                                col.append(item.get(child, ""))
                        else:
                            col.append("")
                    return {field: col}

                # parent 是 dict -> 直接取 child（作为单元）
                if isinstance(parent_val, dict):
                    # 如果 parent_val[child] 是 list of dict, 展开为多列
                    val = parent_val.get(child, "")
                    if isinstance(val, list) and all(isinstance(x, dict) for x in val):
                        return extract_list_of_dict(val, f"{parent}.{child}")
                    # 否则作为单列
                    if isinstance(val, list):
                        return {field: val}
                    return {field: [val]}

                return {field: [""]}

            # 非点字段（可能为 list / dict / 标量）
            value = self.outputs.get(field, "")

            # list of dict -> 展开成多列 field.subkey
            if isinstance(value, list) and all(isinstance(x, dict) for x in value):
                return extract_list_of_dict(value, field)

            # dict -> 检查 dict 内部是否有 list of dict，要进一步展开
            if isinstance(value, dict):
                nested_cols = {}
                for k, v in value.items():
                    # 如果 v 是 list of dict -> 展开为 field.k.subkey
                    if isinstance(v, list) and all(isinstance(x, dict) for x in v):
                        nested_cols.update(extract_list_of_dict(v, f"{field}.{k}"))
                    # 如果 v 是普通 list -> 作为 field.k 一列
                    elif isinstance(v, list):
                        nested_cols[f"{field}.{k}"] = v
                    # 如果 v 是 dict -> 展开为 field.k.subkey（单元素列）
                    elif isinstance(v, dict):
                        for kk, vv in v.items():
                            nested_cols[f"{field}.{k}.{kk}"] = [vv]
                    else:
                        nested_cols[f"{field}.{k}"] = [v]
                if nested_cols:
                    return nested_cols
                # 若 dict 为空或没可展开项，退回为一个单列字符串表示
                return {field: [str(value)]}

            # 普通 list -> 直接作为一列
            if isinstance(value, list):
                return {field: value}

            # 标量 -> 单列
            return {field: [value]}

        # ---- collect columns in order of fields_list ----
        columns = {}
        col_order = []  # 保持列顺序
        for field in fields_list:
            col_dict = get_field_columns(field)
            for name, values in col_dict.items():
                # 如果名字已存在且你现在不想处理重复，只跳过或重写（这里选择重写）
                if name in columns:
                    # 你提到先不处理重复，这里用已有列覆盖新列（可按需改）
                    columns[name] = values
                else:
                    columns[name] = values
                    col_order.append(name)

        # ---- align lengths (用空字符串补齐) ----
        max_len = max((len(col) for col in columns.values()), default=0)
        for key in list(columns.keys()):
            col = columns[key]
            if len(col) < max_len:
                columns[key] = col + [""] * (max_len - len(col))

        # ---- write csv using col_order ----
        os.makedirs(os.path.dirname(savepath), exist_ok=True)
        with open(savepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(col_order)
            for row in zip(*(columns[name] for name in col_order)):
                writer.writerow(row)

# if __name__ == "__main__":
#     logger = BaseLogger("../cache/test.json", "../cache/test.txt")
#
#     # 基本用法
#     logger.info("这是一个信息日志")
#
#     # 带格式化的用法
#     logger.info("训练进度: epoch=%d/%d, loss=%.4f", 10, 100, 0.1234)
#
#     # 带额外信息的用法
#     logger.info("模型评估结果", extra={"accuracy": 0.95, "f1": 0.92})
#
#     logger.info("这条日志会写入文件", is_logfile=False)
#
#     # 耗时统计
#     logger.time_start("训练流程")
#
#     # 信息日志
#     logger.info("实验配置", extra={"batch_size": 32, "epochs": 100}, is_logfile=True)
#
#     # 结构化记录
#     logger.log("config", {"lr": 0.01, "optimizer": "Adam"})
#
#     for epoch in range(100):
#         #logger.add_field(f"epochs.{epoch}.loss", 0.1 / (epoch + 1))
#         logger.log(f"epochs.loss", 0.1 / (epoch + 1))
#         logger.info("进度: %d%%", (epoch + 1), is_logfile=True)
#
#     # 结束统计
#     logger.time_end("训练流程")
#     logger.save_to_json()
if __name__ == "__main__":
    logger = BaseLogger("../cache/wfa_result.json", "../cache/test.txt")
    logger.load_from_json()
    logger.print_logs()
    logger.select_fields2csv(["train.loss", "valid.result", "time"], "../cache/test.csv")
